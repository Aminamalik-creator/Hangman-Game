#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define MAX_WORD_LENGTH 100
#define MAX_ATTEMPTS 6

// Structure to hold the game data
typedef struct {
    char word[MAX_WORD_LENGTH];
    char guessed[MAX_WORD_LENGTH];
    int attemptsLeft;
} HangmanGame;

// Function prototypes
void initializeGame(HangmanGame *game, const char *word, int attempts);
void displayWord(const char *guessed);
int isWordGuessed(const char *word, const char *guessed);
void processGuess(HangmanGame *game, char guess);

int main() {
    HangmanGame game;
    char category;
    const char *wordToGuess;

    // Predefined categories and words
    const char *fruits[] = {"apple", "banana", "cherry"};
const char *colors[] = {"red", "blue", "green"};
    const char *vegetables[] = {"carrot", "potato", "spinach"};

    printf("Welcome to Hangman!\n");
    printf("Select a category:\n");
    printf("1. Fruit Names\n");
    printf("2. Color Names\n");
    printf("3. Vegetable Names\n");
    printf("Enter your choice (1/2/3): ");
    scanf(" %c", &category);

    switch (category) {
        case '1':
            wordToGuess = fruits[rand() % 3];
            printf("You selected: Fruit Names\n");
            break;
        case '2':
            wordToGuess = colors[rand() % 3];
            printf("You selected: Color Names\n");
            break;
        case '3':
            wordToGuess = vegetables[rand() % 3];
            printf("You selected: Vegetable Names\n");
break;
        default:
            printf("Invalid choice! Defaulting to Fruit Names.\n");
            wordToGuess = fruits[rand() % 3];
   
 }

    // Set number of attempts based on word length
    int attempts = strlen(wordToGuess) + 3;

    // Initialize the game
    initializeGame(&game, wordToGuess, attempts);

    // Game loop
    while (game.attemptsLeft > 0) {
        printf("\nWord to guess: ");
        displayWord(game.guessed);
        printf("\nAttempts left: %d\n", game.attemptsLeft);
        printf("Enter your guess: ");

        char guess;
        scanf(" %c", &guess);

// Convert guess to lowercase for case insensitivity
        guess = tolower(guess);

        processGuess(&game, guess);

        if (isWordGuessed(game.word, game.guessed)) {
      
      printf("\nCongratulations! You guessed the word: %s\n", game.word);
            break;
        }
    }

    if (game.attemptsLeft == 0) {
        printf("\nGame over! The word was: %s\n", game.word);
    }

    return 0;
}

// Function to initialize the game
void initializeGame(HangmanGame *game, const char *word, int attempts) {
    strncpy(game->word, word, MAX_WORD_LENGTH);
    size_t length = strlen(word);
for (int i = 0; i < length; i++) {
        game->guessed[i] = '_';
    }

    game->guessed[length] = '\0';
    game->attemptsLeft = attempts;
}

// Function to display the guessed word
void displayWord(const char *guessed) {
    for (int i = 0; guessed[i] != '\0'; i++) {
        printf("%c ", guessed[i]);
    }
    printf("\n");
}

// Function to check if the word is fully guessed
int isWordGuessed(const char *word, const char *guessed) {
    return strcmp(word, guessed) == 0;
}

// Function to process a player's guess
void processGuess(HangmanGame *game, char guess) {
    int found = 0;
    size_t length = strlen(game->word);

    for (int i = 0; i < length; i++) {
        if (game->word[i] == guess) {
            game->guessed[i] = guess;
            found = 1;
        }
    }

    if (!found) {
        game->attemptsLeft--;
        printf("Incorrect guess!\n");
    } else {
        printf("Good guess!\n");
    }
}

